<?php
session_start();
?>
<html>
<head>
  <?php
  if($_SESSION["username"] == NULL)
  {
    session_destroy();
    echo '<meta http-equiv="refresh" content="3;url=index.html">';
  }
  ?>
  <meta charset="utf-8"/>
    <title>Buy a ticket</title>
    <link rel="stylesheet" type="text/css"  href="buywelcome.css">
</head>
<body>
  <?php
  if($_SESSION["username"] == NULL)
  {
  echo '<script>alert("You have not logged in");</script>';
  }
  ?>
  <div class="white-box">
  </div>
  <a class="buy" href="buywelcome.php">Buy A Ticket</a>
  <a class="review" href="comment.php">Movie Review</a>
  <a class="history" href="history.php">Purchase History</a>
  <a class="logout" href="logout.php">Logout</a>
<br>
<br>
<br>
<br>

<?php
$db_conn=mysqli_connect("sophia.cs.hku.hk", "cswong", "CecHZnuc", "cswong")
or die("Connection Error!".mysqli_connect_error());

$query = "SELECT * FROM `Film Table`";
$result = mysqli_query($db_conn, $query)
or die ('Failed to query '.mysqli_error($db_conn));

while($fetch = mysqli_fetch_array($result))
{
echo "<div>";
echo "<h1>".$fetch['FilmName']."</h1>";
echo '<img src="'.$fetch['FilmId'].'.jpg" alt="picture" width="200" height="300">';
echo "<h3> Synopsis: ".$fetch['Description']."</h3>";
echo "<h4> Director: ".$fetch['Director']."</h4>";
echo "<h4> Duration: ".$fetch['Duration']."</h4>";
echo "<h4> Category: ".$fetch['Category']."</h4>";
echo "<h4> Language: ".$fetch['Language']."</h4><br>";
$temp = $fetch['FilmId'];
$broadcastquery = "SELECT * FROM `BroadCast table` WHERE FilmID = $temp";
$broadcastresult = mysqli_query($db_conn, $broadcastquery)
or die ('Failed to query '.mysqli_error($db_conn));
$temp = 0;
echo '<form action="seatplantry.php" name="submit'.$temp.'" id="submit" method="post"> <select name="choice" id="choice">';
while($broadcastfetch = mysqli_fetch_array($broadcastresult))
{
  echo '<option name="'.$broadcastfetch['BroadCastId'].'"value="'.$broadcastfetch['BroadCastId'].'">'.$broadcastfetch['Dates'].' '.$broadcastfetch['Time'].' ('.$broadcastfetch['day'].') House '.$broadcastfetch['HouseId'];
  echo "</option>";
}
echo "</select>";
echo '<input type="submit" value="Submit">';
echo '</form>';
echo "<hr></div>";
$temp = $temp + 1;
}
?>

</body>
</html>
