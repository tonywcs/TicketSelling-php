<?php
session_start();
?>
<html>
<head>
  <?php
  if($_SESSION["username"] == NULL)
  {
    session_destroy();
    echo '<meta http-equiv="refresh" content="3;url=index.html">';
  }
  ?>
  <meta charset="utf-8"/>
    <title>Movie Review</title>
    <link rel="stylesheet" type="text/css"  href="comment.css">
</head>
<body>
  <?php
  if($_SESSION["username"] == NULL)
  {
  echo '<script>alert("You have not logged in");</script>';
  }
  ?>
  <a class="buy" href="buywelcome.php">Buy A Ticket</a>
  <a class="review" href="comment.php">Movie Review</a>
  <a class="history" href="history.php">Purchase History</a>
  <a class="logout" href="logout.php">Logout</a>
<br>
<br>
<br>
<form action="comment_submit.php" method="post">
  <p>Film name: </p>
  <select name="filmtocomment" id="filmtocomment">
<?php
$db_conn=mysqli_connect("sophia.cs.hku.hk", "cswong", "CecHZnuc", "cswong")
or die("Connection Error!".mysqli_connect_error());

$query = "SELECT * FROM `Film Table`";
$result = mysqli_query($db_conn, $query)
or die ('Failed to query '.mysqli_error($db_conn));

while($fetch = mysqli_fetch_array($result))
{
  echo '<option name="'.$fetch['FilmId'].'"value="'.$fetch['FilmId'].'">'.$fetch['FilmName'];
  echo "</option>";
}
?>
  </select>
  <br>
  <input id="comment" class="comment" name="comment" type="text" placeholder="Please input comment here" required>
  <br>
  <input type="submit" value="Submit comment">
</form>
  <button id="recomment" name="recomment" type="button">View comment</button>
<hr>
<div id="entries">
</div>
<script>
var button = document.getElementById("recomment");
var filmid = document.getElementById("filmtocomment");
button.addEventListener("click", retrieve);
function retrieve()
{
  var xmlhttp;
  var value = filmid.options[filmid.selectedIndex].value;
  if (window.XMLHttpRequest)
  {
  xmlhttp = new XMLHttpRequest();
  } else
  {
  xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
  }

  xmlhttp.onreadystatechange = function()
  {
  if (xmlhttp.readyState == 4  && xmlhttp.status ==200)
  {
  var mesgs = document.getElementById("entries");
  mesgs.innerHTML = xmlhttp.responseText;
  }
  }
  var query = "id="+value;
  xmlhttp.open('GET', 'comment_retrieve.php?'+query, true);
  //xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xmlhttp.send();
}
</script>
</body>
</html>
