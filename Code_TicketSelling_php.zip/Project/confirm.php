<?php
session_start();
?>
<html>
<head>
  <?php
  if($_SESSION["username"] == NULL)
  {
    session_destroy();
    echo '<meta http-equiv="refresh" content="3;url=index.html">';
  }
  ?>
  <meta charset="utf-8"/>
    <title>Confirmation</title>
    <link rel="stylesheet" type="text/css"  href="confirm.css">
</head>
<body>
  <?php
  if($_SESSION["username"] == NULL)
  {
  echo '<script>alert("You have not logged in");</script>';
  }
  $broadcastid = $_SESSION["broadcastid"];
  $seatarray = $_SESSION["seatarray"];
  $userid = $_SESSION["username"];
  ?>
  <a class="buy" href="buywelcome.php">Buy A Ticket</a>
  <a class="review" href="comment.php">Movie Review</a>
  <a class="history" href="history.php">Purchase History</a>
  <a class="logout" href="logout.php">Logout</a>
  <br>
  <br>
  <br>
<h1>Order Information</h1>
<?php
$ticketarray = $_POST['ticketarray'];
$total = 0;
$N = count($seatarray);
for($i=0; $i < $N; $i++)
{
  echo '<table class="information" align="center">';
  $db_conn=mysqli_connect("sophia.cs.hku.hk", "cswong", "CecHZnuc", "cswong")
  or die("Connection Error!".mysqli_connect_error());
  $broadcastid = $_SESSION["broadcastid"];
  $broadcastquery = "SELECT * FROM `BroadCast table` WHERE BroadCastId = $broadcastid";
  $broadcastresult = mysqli_query($db_conn, $broadcastquery)
  or die ('Failed to query '.mysqli_error($db_conn));
  $fetch = mysqli_fetch_array($broadcastresult);
  echo "<tr><td>Cinema:</td><td>US Cinema</td><tr><td>House:</td><td>House ";
  echo $fetch['HouseId'];
  echo "</td></tr>";

  echo "<tr><td>SeatNo:</td><td>".$seatarray[$i]."</td>";

  echo"<tr><td>Film:</td><td>";
  $filmid = $fetch['FilmId'];
  $filmquery = "SELECT * FROM `Film Table` WHERE FilmId = $filmid";
  $filmresult = mysqli_query($db_conn, $filmquery)
  or die ('Failed to query '.mysqli_error($db_conn));
  $filmfetch = mysqli_fetch_array($filmresult);
  echo $filmfetch['FilmName'];
  echo "</td></tr>";
  echo "<tr><td>Category:</td><td>";
  echo $filmfetch['Category'];
  echo "</td></tr>";
  echo "<tr><td>Show Time:</td><td>";
  echo $fetch['Dates']."(".$fetch['day'].")".$fetch['Time'];
  echo "</td></tr>";
  if ($ticketarray[$i] == "Adult")
  {
    $feearray[$i] = 75;
  }
  else
  {
    $feearray[$i] = 50;
  }
  $total = $total + $feearray[$i];
  echo "<tr><td>Ticket Fee:</td><td>$".$feearray[$i]."(".$ticketarray[$i].")";
  echo "</table>";
  echo "<hr>";

  $sendquery = "INSERT INTO `Ticket Table` (SeatNo, BroadCastId, Valid, UserId, TicketType, TicketFee) VALUES ('$seatarray[$i]', '$broadcastid', 'yes', '$userid', '$ticketarray[$i]', '$feearray[$i]')";
  $sendresult = mysqli_query($db_conn, $sendquery)
  or die ('Failed to query '.mysqli_error($db_conn));
}
echo '<div class="text">';
echo "Total fee:".$total;
echo "<br>Please present valid proof of age/status when purchasing Student or Senior tickets before entering the cinema house";
echo '</div>';
?>
<button class="submit" onclick="location.href = 'buywelcome.php';" type="button">OK</button>
</body>
</html>
