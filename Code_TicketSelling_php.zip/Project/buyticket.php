<?php
session_start();
?>
<html>
<head>
  <?php
  if($_SESSION["username"] == NULL)
  {
    session_destroy();
    echo '<meta http-equiv="refresh" content="3;url=index.html">';
  }
  ?>
  <meta charset="utf-8"/>
    <title>Choose your ticket</title>
    <link rel="stylesheet" type="text/css"  href="buyticket.css">
</head>
<body>
  <?php
  if($_SESSION["username"] == NULL)
  {
  echo '<script>alert("You have not logged in");</script>';
  }
  ?>
<h1>Cart</h1>
<table class="information">
<tr>
  <td>Cinema:</td>
  <td>US</td>
</tr>
<tr>
  <td>House:</td>
  <td>House
      <?php
      $db_conn=mysqli_connect("sophia.cs.hku.hk", "cswong", "CecHZnuc", "cswong")
      or die("Connection Error!".mysqli_connect_error());
      $broadcastid = $_SESSION["broadcastid"];
      $broadcastquery = "SELECT * FROM `BroadCast table` WHERE BroadCastId = $broadcastid";
      $broadcastresult = mysqli_query($db_conn, $broadcastquery)
      or die ('Failed to query '.mysqli_error($db_conn));
      $fetch = mysqli_fetch_array($broadcastresult);
      echo $fetch['HouseId'];
      echo "</td></tr><tr><td>Film:</td><td>";
      $filmid = $fetch['FilmId'];
      $filmquery = "SELECT * FROM `Film Table` WHERE FilmId = $filmid";
      $filmresult = mysqli_query($db_conn, $filmquery)
      or die ('Failed to query '.mysqli_error($db_conn));
      $filmfetch = mysqli_fetch_array($filmresult);
      echo $filmfetch['FilmName'];
      echo "</td></tr>";
      echo "<tr><td>Category:</td><td>";
      echo $filmfetch['Category'];
      echo "</td></tr>";
      echo "<tr><td>Show Time:</td><td>";
      echo $fetch['Dates']."(".$fetch['day'].")".$fetch['Time'];
      echo "</td></tr>";
      ?>
</table>
<form action="confirm.php" method="post">
  <table class="selection">
  <?php
    $seatarray = $_POST['seatarray'];
    $_SESSION["seatarray"] = $seatarray;
    if(empty($seatarray))
      {
        echo "You didn't select any seats.<br>";
        echo '<script>document.getElementById("submit").style.visibility = "none";</script>';
      }
    else
      {
        $N = count($seatarray);
        for($i=0; $i < $N; $i++)
        {
        echo '<tr><td>';
        echo $seatarray[$i];
        echo '</td><td>';
        echo ' <select name="ticketarray[]">';
        echo '<option value="Adult">Adult($75)</option>';
        echo '<option value="Student/Senior">Student/Senior($50)</option>';
        echo "</select></td><tr>";
        }
      }
  ?>
</table>
<input type="submit" id="submit" name="submit" value="Submit">
</form>
<button class="button" onclick="location.href = 'buywelcome.php';" type="button">Cancel</button>
</body>
</html>
