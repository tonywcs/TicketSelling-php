<?php
session_start();
?>
<html>
<head>
  <?php
  $db_conn=mysqli_connect("sophia.cs.hku.hk", "cswong", "CecHZnuc", "cswong")
  or die("Connection Error!".mysqli_connect_error());

  $username = $_POST["username"];
  $password = $_POST["password"];

  $query = "SELECT * FROM `Login Table` WHERE UserId= '$username'";
  $result = mysqli_query($db_conn, $query)
  or die ('Failed to query '.mysqli_error($db_conn));
  $fetch = mysqli_fetch_array($result);

  if( $password == $fetch['PW'] )
  {
    $temp = 1;
    $_SESSION["username"] = "$username";
    echo '<meta http-equiv="refresh" content="0;url=main.php">';
  }
  else
  {
    $temp = 0;
    session_destroy(); 
    echo '<meta http-equiv="refresh" content="3;url=index.html">';
  }
  ?>
</head>
<body>
<?php
if($temp == 0)
{
  echo "<h1>Invalid login, please login again.</h1>";
}

mysqli_free_result($result);
mysqli_close($db_conn);
?>

</body>
</html>
