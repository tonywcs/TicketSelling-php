<?php
session_start();
?>
<html>
<head>
  <?php
  if($_SESSION["username"] == NULL)
  {
    session_destroy();
    echo '<meta http-equiv="refresh" content="3;url=index.html">';
  }
  else
  {
    echo '<meta http-equiv="refresh" content="3;url=comment.php">';
  }
  ?>
</head>
<body>
  <?php
  if($_SESSION["username"] == NULL)
  {
  echo '<script>alert("You have not logged in");</script>';
  }
  else
  {
  echo '<h1>Your comment has been submitted</h1>';
  }
  $db_conn=mysqli_connect("sophia.cs.hku.hk", "cswong", "CecHZnuc", "cswong")
  or die("Connection Error!".mysqli_connect_error());

  $filmid = $_POST['filmtocomment'];
  $userid = $_SESSION["username"];
  $comment = $_POST['comment'];
  $sendquery = "INSERT INTO `Comment table` (FilmId, UserId, Comment) VALUES ('$filmid', '$userid', '$comment')";
  $sendresult = mysqli_query($db_conn, $sendquery)
  or die ('Failed to query '.mysqli_error($db_conn));
  ?>

</body>
</html>
