<?php
session_start();
?>
<html>
<head>
  <?php
  if($_SESSION["username"] == NULL)
  {
    session_destroy();
    echo '<meta http-equiv="refresh" content="3;url=index.html">';
  }
  ?>
  <meta charset="utf-8"/>
    <title>Choose your seat</title>
    <link rel="stylesheet" type="text/css"  href="seatplantry.css">
</head>
<body>
  <?php
  if($_SESSION["username"] == NULL)
  {
  echo '<script>alert("You have not logged in");</script>';
  }
  ?>
  <br><br>
<h1>Ticketing</h1>
<table class="information">
<tr>
  <td>Cinema:</td>
  <td>US</td>
</tr>
<tr>
  <td>House:</td>
  <td>House
      <?php
      $db_conn=mysqli_connect("sophia.cs.hku.hk", "cswong", "CecHZnuc", "cswong")
      or die("Connection Error!".mysqli_connect_error());
      $broadcastid = $_POST['choice'];
      $_SESSION["broadcastid"] = $broadcastid;
      $broadcastquery = "SELECT * FROM `BroadCast table` WHERE BroadCastId = $broadcastid";
      $broadcastresult = mysqli_query($db_conn, $broadcastquery)
      or die ('Failed to query '.mysqli_error($db_conn));
      $fetch = mysqli_fetch_array($broadcastresult);
      echo $fetch['HouseId'];
      echo "</td></tr><tr><td>Film:</td><td>";
      $filmid = $fetch['FilmId'];
      $filmquery = "SELECT * FROM `Film Table` WHERE FilmId = $filmid";
      $filmresult = mysqli_query($db_conn, $filmquery)
      or die ('Failed to query '.mysqli_error($db_conn));
      $filmfetch = mysqli_fetch_array($filmresult);
      echo $filmfetch['FilmName'];
      echo "</td></tr>";
      echo "<tr><td>Category:</td><td>";
      echo $filmfetch['Category'];
      echo "</td></tr>";
      echo "<tr><td>Show Time:</td><td>";
      echo $fetch['Dates']."(".$fetch['day'].")".$fetch['Time'];
      echo "</td></tr>";
      ?>
</table>
<br>
<br>
<br>
<form action="buyticket.php" name = "buyticket" method="post" onSubmit="return validate()">
      <?php
      $houseid = $fetch['HouseId'];
      $housequery = "SELECT * FROM `House Table` WHERE HouseId = '$houseid'";
      $houseresult = mysqli_query($db_conn, $housequery)
      or die ('Failed to query '.mysqli_error($db_conn));
      $housefetch = mysqli_fetch_array($houseresult);
      $row = $housefetch['HouseRow'];
      $col = $housefetch['HouseCol'];
      //$seat = 1;
      if($row == 6) $seatrow = "F";
      if($row == 5) $seatrow = "E";
      if($row == 4) $seatrow = "D";
      echo '<table class="seatplan">';
      for ($i = 1; $i <= $row; $i++)
      {
        echo "<tr>";
        for ($j = 1; $j <= $col; $j++)
        {
          $seat = $seatrow.$j;
          $ticketquery = "SELECT * FROM `Ticket Table` WHERE BroadCastId = $broadcastid AND SeatNo = '$seat'";
          $ticketresult = mysqli_query($db_conn, $ticketquery)
          or die ('Failed to query '.mysqli_error($db_conn));
          $ticketfetch = mysqli_fetch_array($ticketresult);
          if ($ticketfetch['Valid'] == NULL)
          {
            echo '<td class="available">';
            echo $seat;
            echo '<input type="checkbox" name="seatarray[]" value="'.$seat.'" onclick="checkCheckBox()">';
            echo "</td>";
          }
          else
          {
            echo '<td class="sold">';
            echo $seat;
            echo "sold";
            echo "</td>";
          }
        }
        echo "</tr>";
        $seatrow = chr(ord($seatrow) - 1);
      }
      echo "</table>";
      echo '<p class="screen">SCREEN</p>';
      ?>
<input type="submit" id="submit" name="submit" value="Submit">
</form>
<button class="button"; onclick="location.href = 'buywelcome.php';" type="button">Cancel</button>
</body>
<script>
function validate()
{
var chks = document.getElementsByName('seatarray[]');
var hasChecked = false;
for (var i = 0; i < chks.length; i++)
{
	if (chks[i].checked)
	{
	hasChecked = true;
	break;
	}
}

if (hasChecked == false)
	{
	alert("Please select at least one.");
	return false;
	}

return true;
}
</script>
</html>
