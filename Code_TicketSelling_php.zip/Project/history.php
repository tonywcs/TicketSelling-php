<?php
session_start();
?>
<html>
<head>
  <?php
  if($_SESSION["username"] == NULL)
  {
    session_destroy();
    echo '<meta http-equiv="refresh" content="3;url=index.html">';
  }
  ?>
  <meta charset="utf-8"/>
    <title>Purchase History</title>
    <link rel="stylesheet" type="text/css"  href="history.css">
</head>
<body>
  <?php
  if($_SESSION["username"] == NULL)
  {
  echo '<script>alert("You have not logged in");</script>';
  }
  $username = $_SESSION['username'];
  ?>
  <a class="buy" href="buywelcome.php">Buy A Ticket</a>
  <a class="review" href="comment.php">Movie Review</a>
  <a class="history" href="history.php">Purchase History</a>
  <a class="logout" href="logout.php">Logout</a>
  <br>
  <br>
  <br>
<h1 align="center">Purchase History</h1>
<br>
<h3 align="center">Username :
<?php
echo $username;
echo "</h3>";
$db_conn=mysqli_connect("sophia.cs.hku.hk", "cswong", "CecHZnuc", "cswong")
or die("Connection Error!".mysqli_connect_error());
$ticketquery = "SELECT * FROM `Ticket Table` WHERE UserId = '$username'";
$ticketresult = mysqli_query($db_conn, $ticketquery)
or die ('Failed to query '.mysqli_error($db_conn));

while($fetch = mysqli_fetch_array($ticketresult))
{
  $broadcastid =$fetch['BroadCastId'];
  $broadcastquery = "SELECT * FROM `BroadCast table` WHERE BroadCastId = $broadcastid";
  $broadcastresult = mysqli_query($db_conn, $broadcastquery)
   or die ('Failed to query '.mysqli_error($db_conn));
  $broadcastfetch = mysqli_fetch_array($broadcastresult);
  $filmid = $broadcastfetch['FilmId'];
  $filmquery = "SELECT * FROM `Film Table` WHERE FilmId = $filmid";
  $filmresult = mysqli_query($db_conn, $filmquery)
   or die ('Failed to query '.mysqli_error($db_conn));
  $filmfetch = mysqli_fetch_array($filmresult);

  echo "<p>TicketId:".$fetch['TicketId']." $".$fetch['TicketFee']."(".$fetch['TicketType'].")</p>";
  echo "<p>House:".$broadcastfetch['HouseId']."</p>";
  echo "<p>Seat: ".$fetch['SeatNo']."</p>";
  echo "<p>FilmnName: ".$filmfetch['FilmName']."(".$filmfetch['Category'].") ".$filmfetch['Duration']."</p>";
  echo "<p>Language: ".$filmfetch['Language']."</p>";
  echo "<p>Date: ".$broadcastfetch['Dates']."(".$broadcastfetch['day'].") ".$broadcastfetch['Time']."</p>";
  echo "<hr><hr>";
}
?>
</body>
</html>
