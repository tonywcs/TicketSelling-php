<?php
session_start();
?>
<html>
<head>
  <?php
    session_destroy();
    echo '<meta http-equiv="refresh" content="3;url=index.html">';
  ?>
</head>
<body>
  <h2>Logging out</h2>
</body>
</html>
