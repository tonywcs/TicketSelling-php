<?php
$db_conn=mysqli_connect("sophia.cs.hku.hk", "cswong", "CecHZnuc", "cswong")
or die ('Error! '.mysqli_connect_error($conn));
$filmid = $_GET['id'];
$query = "SELECT * FROM `Comment table` WHERE FilmId = $filmid";
$result = mysqli_query($db_conn, $query)
or die ('Failed to query '.mysqli_error($db_conn));

while($fetch = mysqli_fetch_array($result))
{
echo "<div id=".$fetch['CommentId'].">";
echo "Viewer: ".$fetch['UserId']."<br>";
echo "Comment: ".$fetch['Comment']."<br>";
echo "</div><hr>";
}

mysqli_free_result($result);
mysqli_close($db_conn);
?>
