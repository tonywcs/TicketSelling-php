<?php
session_start();
?>
<meta charset="utf-8"/>
  <title>Welcome</title>
  <link rel="stylesheet" type="text/css"  href="main.css">
<html>
<head>
  <?php
  if($_SESSION["username"] == NULL)
  {
    session_destroy();
    echo '<meta http-equiv="refresh" content="3;url=index.html">';
  }
  ?>
</head>
<body>
  <?php
  if($_SESSION["username"] == NULL)
  {
  echo '<script>alert("You have not logged in");</script>';
  }
  ?>
  <div class="white-box">
  </div>
  <a class="buy" href="buywelcome.php">Buy A Ticket</a>
  <a class="review" href="comment.php">Movie Review</a>
  <a class="history" href="history.php">Purchase History</a>
  <a class="logout" href="logout.php">Logout</a>
</body>
</html>
